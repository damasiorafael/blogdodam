<div id="search">
<form method="get" action="<?php echo home_url(); ?>">
<input name="s" type="text" class="sbar" value="Search here" onfocus="if (this.value == 'Search here') {this.value = '';}" onblur="if (this.value == '') {this.value = 'Search here';}" size="10" tabindex="1" />
<input type="submit" class="submit" alt="search" value="GO" />
</form>
</div>